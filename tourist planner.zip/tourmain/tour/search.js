document.getElementById('searchButton').addEventListener('click', function () {
    performSearch();
  });
  
  // Function to perform the search and scroll to the first occurrence
  function performSearch() {
    var searchQuery = document.getElementById('searchInput').value.toLowerCase();
    var contentToSearch = document.body.textContent.toLowerCase(); // You can specify a different container if needed
  
    var searchIndex = contentToSearch.indexOf(searchQuery);
  
    if (searchIndex !== -1) {
      // Scroll to the first occurrence of the search term
      var startIndex = Math.max(0, searchIndex - 30); // Adjust the scroll position as needed
      var endIndex = Math.min(contentToSearch.length, searchIndex + searchQuery.length + 30);
      var context = contentToSearch.substring(startIndex, endIndex);
  
      var resultItem = document.createElement('p');
      resultItem.textContent = context;
      document.getElementById('searchResults').innerHTML = '';
      document.getElementById('searchResults').appendChild(resultItem);
  
      // Scroll to the element with the first occurrence of the search term
      var firstOccurrence = document.body.textContent.indexOf(context);
      var elementToScrollTo = document.body.childNodes[0]; // You may need to adjust this selector based on your HTML structure
      var yOffset = elementToScrollTo.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({ top: yOffset, behavior: 'smooth' });
    } else {
      document.getElementById('searchResults').innerHTML = 'No results found.';
    }
  }
  